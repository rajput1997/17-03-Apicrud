﻿using DAL.Models;
using Microsoft.EntityFrameworkCore;
using System;

namespace DAL
{
    public class UserDbContext : DbContext
    {
        public UserDbContext(DbContextOptions<UserDbContext> options) : base(options)
        {

        }
        public DbSet<User> UserRegistration { get; set; }
    }
}
