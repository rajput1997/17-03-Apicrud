﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using Utility;
using DAL;
using DAL.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly UserDbContext _auc;
        public UserController(UserDbContext auc)
        {
            _auc = auc;
        }
        // GET: api/<UserController>
        public IEnumerable<User> GetUser()
        {
            var uee = _auc.UserRegistration.ToList();
            return uee;
        }
        // GET api/<UserController>/5
        [HttpGet("{id}")]
        public User Get(int id)
        {
            return _auc.UserRegistration.FirstOrDefault(s => s.UserId == id);
        }

        // POST api/<UserController>
        [Route("AddUser")]
        [HttpPost]
 
        public User AddUser(User ue)
        {
            if (ue != null)
            {
                ue.Pwd = EncDecPassword.MD5Hash(ue.Pwd.ToString());
                _auc.UserRegistration.Add(ue);
                _auc.SaveChanges();
                return ue;
            }
            return null;
        }
        // PUT api/<UserController>/5
        [HttpPut("{id}")]
        public void Put(int id)
        {
            var ue = _auc.UserRegistration.FirstOrDefault(s => s.UserId == id);
            if (ue != null)
            {
                _auc.Entry<User>(ue).CurrentValues.SetValues(ue);
                _auc.SaveChanges();
            }
        }

        // DELETE api/<UserController>/5
        [HttpDelete("{id}")]

        public void Delete(int id)
        {
            var stu = _auc.UserRegistration.FirstOrDefault(s => s.UserId == id);
            if (stu != null)
            {
                _auc.UserRegistration.Remove(stu);
                _auc.SaveChanges();
            }
        }
        //Login api/UserController
        [HttpPost]
        public IActionResult Login(User lo)
        {
            var userlist = _auc.UserRegistration.ToList();
            lo.Pwd = EncDecPassword.MD5Hash(lo.Pwd);
            var value = _auc.UserRegistration.Where(a => a.Pwd == lo.Pwd && a.Username == lo.Username).SingleOrDefault();
            if (value != null)
            {
                return RedirectToAction();
            }
            else
            {
                return null;
            }
        }

    }
}

